
<?php
#include('menu.php');
include('header.php') ;
#error_reporting(0);
?>

<div class="box">
  <div class="container-3">
  <?php
  $table = 'users' ;
  echo "<form action=\"usersearch.php\" name=\"import\" method=\"get\" enctype=\"multipart/form-data\">" ;
  echo '<input id="tea-submit" type="hidden" name="Table" value="',$table,'">' ;
  ?>
  
    <span class="icon"><i class="fa fa-search"></i></span>
	   
      <input type="search" name="search" id="search" placeholder="Search..." /> 
	 </form>
  </div>
</div>
<br>
<br>
<?php
#if ( isset($_GET['submit'])) {
#$database = 'arab';
$a = $_GET['search'];
$criteria = '*'.$a; // you can use * and ? as jokers

#$dbh = new PDO("mysql:host=127.0.0.1;dbname={$database};charset=utf8", 'root', '');
$dbh = new PDO("mysql:host={$DBhost};dbname={$database};charset=utf8", $DBusername, $DBpassword);
$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

#$tables = $dbh->query("SHOW TABLES");
#$tables = $GET['search']; 
$tablename = 'users' ;
$table = 'users';
#$table = $table . $id ;
#$table = base64_encode($table) ;
$fields = $dbh->prepare("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?");
    $fields->execute(array ($database, $table));

    $ors = array ();
    while (($field = $fields->fetch(PDO::FETCH_NUM)) !== false)
    {
		if($id2 == '1'){
		
    	$ors[] = str_replace("`", "``", $field[0]) . " LIKE REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:search, '\\\\', '\\\\\\\\'), '%', '\\%'), '_', '\\_'), '*', '%'), '?', '_')";
		}
		#else{
		#if($id == $id2){
		#	        $ors[] = str_replace("`", "``", $field[0]) . " LIKE REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:search, '\\\\', '\\\\\\\\'), '%', '\\%'), '_', '\\_'), '*', '%'), '?', '_') AND groupID = userId OR groupID = '$id'";

#		}
		else{
        $ors[] = str_replace("`", "``", $field[0]) . " LIKE REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:search, '\\\\', '\\\\\\\\'), '%', '\\%'), '_', '\\_'), '*', '%'), '?', '_') AND groupID = '$id'";
		}
		}
	#}
	
    $request = 'SELECT userId,userName,userEmail,groupName FROM `';
    $request .= str_replace("`", "``", $table);
    $request .= "` WHERE ";
    $request .= implode(' OR ', $ors);
    $rows = $dbh->prepare($request);

    $rows->execute(array ('search' => $criteria));

    $count = $rows->rowCount();
    if ($count == 0)
    {
        continue;
    }

    $str = "<h1>Table {$tablename} contains {$count} </h1> <p><a href=\"sendgroup.php?ID=$id\">Brodcast group</a></p>";;
	
    #echo str_repeat('-', strlen($str)), PHP_EOL;
    echo $str, PHP_EOL;
    #echo str_repeat('-', strlen($str)), PHP_EOL;
	echo "<table border='1' cellpadding='10'>";
    $counter = 1;
$confvalue="return confirm('Are you sure?');";
$confrm = 'onclick='.'"'.$confvalue.'"' ;
$fontdelete ='<center><i class="fa fa-trash"></i></center>' ;
$fontedit='<center><i class="fa fa-pencil"></i></center>' ;
    while (($row = $rows->fetch(PDO::FETCH_ASSOC)) !== false)
    {
        $col = 0;
        $title = "<th>Row #{$counter}: </th>";
		
		echo "<tr>" ;
        #echo $title;
		
        foreach ($row as $column => $value)
        {
		if($column == 'userPass'){
				#break ;
				
				break;
			}	
			
            echo
            (($col++ > 0) ? str_repeat(' ', strlen($title) + 1) : ' '),
            '<th>',$column, '</th>','<td>',$value,'</td>',
			
            #trim(preg_replace('!\s+!', ' ', str_replace(array ("\r", "\t", "\n",), array ("", "", " "), $value))),
            PHP_EOL;
			
			if($column == 'userId'){
				#echo "<td><a  href=\"send.php?Table=users&ID=$value\">Send Message </a></td></td>" ;
				$send = "<td><a  href=\"send.php?Table=users&ID=$value\">Send Message </a></td></td>" ;
				if($id2 == '1'){
				#echo "<td><a  href=\"edituser.php?Table=users&ID=$value\">$fontedit </a></td></td>" ;
				#echo "<td><a href=\"userdelete.php?Table=users&ID=$value\" $confrm>$fontdelete</a></td>";
				#$edit = "<td><a  href=\"edituser.php?Table=users&ID=$value\">$fontedit </a> " ;
				#$delete ="<a href=\"userdelete.php?Table=users&ID=$value\" $confrm>$fontdelete</a></td></td>";
				$edit = "<td><a  href=\"edituser.php?Table=users&ID=$value\">Edit </a> " ;
				$delete ="<a href=\"userdelete.php?Table=users&ID=$value\" $confrm>	Delete</a></td></td>";
				}
				else {
				If($id2 == $id){
				#$Query = mysqli_query($ConnectDB,"SELECT userId FROM `users` WHERE groupID='$id2'");
				
				#while($rowq = mysqli_fetch_row($Query)) {	
				#	echo "<td><a  href=\"edituser2.php?Table=users&ID=$value\">$fontedit </a></td></td>" ;
				#echo "<td><a href=\"userdelete2.php?Table=users&ID=$value\" $confrm>$fontdelete</a></td>";
				#foreach($rowq as $key => $val){
				$edit = "<td><a  href=\"edituser2.php?Table=users&ID=$value\">Edit  </a>" ;
				$delete = "<a href=\"userdelete2.php?Table=users&ID=$value\" $confrm>Delete</a></td></td>";
				#echo $edit ;
				#}
				
				#}
				
				}
				}
			}
			
			echo "</tr>";
			
        }
		
        echo PHP_EOL;
        $counter++;
		
		echo $send ;
		echo $edit ;
		echo $delete ;
		#echo "</tr>";
		#echo '<td>End of result</td>' ;
    }
	echo "</table></div></body>";
	#echo "\n Total of ".$title."\n" ;
	?>
	<?php ob_end_flush(); ?>

