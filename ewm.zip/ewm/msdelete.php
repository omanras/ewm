
<?php

include('header.php');

$id3 = $_GET['ID'] ;


mysqli_query($ConnectDB,"DELETE FROM `message_t` WHERE msID='$id3' AND userResveID='$id2'") or die(mysqli_error($ConnectDB)); 
echo "<meta http-equiv=\"refresh\" content=\"0; url=home.php\" />";

?>
 </body>
 </html>
 <?php ob_end_flush(); ?>
