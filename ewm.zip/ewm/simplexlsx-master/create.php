<?php
include("../head.php") ;
if($id == $id2){
?>

 
 
<?php
#include('include/config.in.php');
//---------------------------------------------------------------------------------------------------
if(isset($_POST["submit"])){
//test extension
$filex = pathinfo($_FILES['file']['name']);	
$extension = $filex['extension'];
$file2 = $_FILES['file']['name'] ;
if($extension == 'xlsx'){
    include ('simplexlsx.class.php');
	
    $xlsx = new SimpleXLSX($file2);
    $fp = fopen( 'tmp.csv', 'w');
    foreach( $xlsx->rows() as $fieldsx ) {
        fputcsv( $fp, $fieldsx);
    }
    fclose($fp);	
	$file = file_get_contents('tmp.csv');
	file_put_contents($file);
	$file = 'tmp.csv' ;
}

else{
	
$file = file_get_contents($_FILES['file']['tmp_name']);
file_put_contents($_FILES['file']['tmp_name'], $file);
$file = $_FILES['file']['tmp_name'];
}
#file_put_contents($_FILES['file']['tmp_name'], $file);
 


$table = $_POST['table'];
if(empty($_POST['table'])){
	#echo "<h2>you must enter table name</h2>" ;
	$filed = 'tmp.csv' ;
	unlink($filed);
	echo "<script>alert('you must enter table name');</script>" ;
	echo "<meta http-equiv=\"refresh\" content=\"0; url=../create.php\" />";
}


else{	
$check = mysqli_query($ConnectDB,"SELECT table_name FROM `files_name` WHERE table_name='$table' AND groupID='$id'") ;
$check_count = mysqli_num_rows($check) ;
if($check_count!=0){
	#echo "<h2>Can't create table change the name </h2>" ;
	$filed = 'tmp.csv' ;
	unlink($filed);
	echo "<script>alert('Can not create table change the name'); </script>" ;
	echo "<meta http-equiv=\"refresh\" content=\"0; url=../create.php\" />";


}
else {
// get structure from csv and insert db
ini_set('auto_detect_line_endings',TRUE);
$handle = fopen($file,'r');
// first row, structure
if ( ($data = fgetcsv($handle) ) === FALSE ) {
	$filed = 'tmp.csv' ;
	unlink($filed);
    echo "<script>alert('Cannot read from csv $file');</script>";
	echo "<meta http-equiv=\"refresh\" content=\"0; url=../create.php\" />";
	die();
	
}

$fields = array();
print_r($fields);
$field_count = 0;
for($i=0;$i<count($data); $i++) {
    $f = strtolower(trim($data[$i]));
    if ($f) {
        // normalize the field name, strip to 20 chars if too long
        #$f = substr(preg_replace ('/[^0-9a-z]/', '_', $f), 0, 20);
        $field_count++;
        #$fields[] = "`$f`".' VARCHAR(255)';
		$fields[] = "`$f`".' TEXT';
    }
}


/* CREATE TABLE IF NOT EXISTS `Table` (
  `idRow` int(7) NOT NULL AUTO_INCREMENT,
  `name1` varchar(50) DEFAULT NULL,
  `email2` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idRow`)
) ENGINE=MYISAM  DEFAULT CHARSET=utf8 ;
 */

$FieldsToAdd=implode(',', $fields);


$table_name="INSERT INTO files_name (table_name,groupID,tableID) VALUES ('$table','$id','')" ;
$Query = mysqli_query($ConnectDB,"$table_name");
$table2 = $table . $id;
$table2 =  base64_encode($table2) ;
$SQL1 = "CREATE TABLE IF NOT EXISTS `$table2` ($FieldsToAdd) ENGINE=MYISAM  DEFAULT CHARSET=utf8"; //ENGINE=MYISAM  DEFAULT CHARSET=utf8 for Arabic Support
echo $SQL1 ;
$Query=mysqli_query($ConnectDB,"$SQL1");

$SQL2 ="ALTER TABLE `$table2` ADD idRow INT( 7 ) NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST ;" ;
$Query=mysqli_query($ConnectDB,"$SQL2");

//insert time to the database
$SQL3="INSERT INTO timerow (filename,Time,groupID) VALUES ('$table',CURRENT_TIME(),'$id')";
mysqli_query($ConnectDB,"$SQL3");

while ( ($data = fgetcsv($handle) ) !== FALSE ) {
    $fields = array();
    for($i=0;$i<$field_count; $i++) {
        $fields[] = '\''.addslashes($data[$i]).'\'';
    }
	$CSVDATA=implode(',',$fields);
	
    $SQL = "insert into `$table2` values('',$CSVDATA)";
	$Query=mysqli_query($ConnectDB,$SQL) or die(mysqli_error($ConnectDB));
	#echo $SQL; 
	
}

fclose($handle);
ini_set('auto_detect_line_endings',FALSE);
#echo $SQL ;
echo "<h2>Please wait<h2> " ;
$filed = 'tmp.csv' ;
unlink($filed);
echo "<meta http-equiv=\"refresh\" content=\"0; url=../home.php\" />";
}
}
}



?>


</body>
</html>
<?php 
}
ob_end_flush(); ?>