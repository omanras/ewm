
<header>
<?php
include("header.php") ;
?>	
</header>

<body>	
<?php
if($id == $id2){


$table = $_GET['Table'];
#$id = $_GET['ID'] ;

if (isset($_GET['Table'])){
	#RENAME TABLE old_table TO new_table;
	#DELETE FROM `$table` WHERE idRow='$id'
	mysqli_query($ConnectDB,"DELETE FROM files_name WHERE table_name = '$table' AND groupID='$id'") ;
	$table = $table . $id ;
	$table = base64_encode($table) ;
	mysqli_query($ConnectDB,"DROP TABLE `$table` ");
	echo "<h2>Table deleted , Please wait ... </h2>" ;
	echo "<meta http-equiv=\"refresh\" content=\"3; url=tablefix.php\" />";
}
}
else{
	echo "NOT ALLOW" ;
}
?>
 </body>
 <footer>
 <?php include("footer.php") ;?>
 </footer>
 </html>
 <?php ob_end_flush(); ?>
