
<?php
#include('menu.php');
include('header.php') ;
#error_reporting(0);


#if ( isset($_GET['submit'])) {
#$database = 'arab';
$a = $_GET['search'];
$criteria = '*'.$a; // you can use * and ? as jokers
$dbh = new PDO("mysql:host={$DBhost};dbname={$database};charset=utf8", $DBusername, $DBpassword);

#$dbh = new PDO("mysql:host=127.0.0.1;dbname={$database};charset=utf8", 'root', '');
$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

#$tables = $dbh->query("SHOW TABLES");
#$tables = $GET['search']; 
$tablename = $_GET['Table'] ;
$table = $_GET['Table'];
$table = $table . $id ;
$table = base64_encode($table) ;
$fields = $dbh->prepare("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?");
    $fields->execute(array ($database, $table));

    $ors = array ();
    while (($field = $fields->fetch(PDO::FETCH_NUM)) !== false)
    {
        $ors[] = str_replace("`", "``", $field[0]) . " LIKE REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:search, '\\\\', '\\\\\\\\'), '%', '\\%'), '_', '\\_'), '*', '%'), '?', '_')";
    }
    $request = 'SELECT * FROM `';
    $request .= str_replace("`", "``", $table);
    $request .= '` WHERE ';
    $request .= implode(' OR ', $ors);
    $rows = $dbh->prepare($request);

    $rows->execute(array ('search' => $criteria));

    $count = $rows->rowCount();
    if ($count == 0)
    {
        continue;
    }

    $str = "<h1>Table {$tablename} contains {$count} </h1>";
	
    #echo str_repeat('-', strlen($str)), PHP_EOL;
    echo $str, PHP_EOL;
    #echo str_repeat('-', strlen($str)), PHP_EOL;
	echo "<table border='0' cellpadding='10'>";
    #echo '<table>' ;
	$counter = 1;
$confvalue="return confirm('Are you sure?');";
$confrm = 'onclick='.'"'.$confvalue.'"' ;
$fontdelete ='<center><i class="fa fa-trash"></i></center>' ;
$fontedit='<center><i class="fa fa-pencil"></i></center>' ;
    while (($row = $rows->fetch(PDO::FETCH_ASSOC)) !== false)
    {
        $col = 0;
        $title = "<th>Row #{$counter}: </th>";
		
		echo "<tr>" ;
        #echo $title;
		
        foreach ($row as $column => $value)
        {
			
            echo
            (($col++ > 0) ? str_repeat(' ', strlen($title) + 1) : ' '),
            '<tr><th>',$column, '</th>','<td>',$value,'</td>',
			
            #trim(preg_replace('!\s+!', ' ', str_replace(array ("\r", "\t", "\n",), array ("", "", " "), $value))),
            PHP_EOL;
			if($column == 'idRow'){
			
				
				echo "<td><a  href=\"tedit.php?Table=$tablename&ID=$value\"> Edit </a></td></td>" ;
				echo "<td><a href=\"tdelete.php?Table=$tablename&Tablename=$tablename&ID=$value\" $confrm>Delete </a></td>";
			}
			echo "</tr>";
        }
        echo PHP_EOL;
        $counter++;
		
		echo '<td>End of result</td>' ;
    }
	echo "</table></div></body>";
	#echo "\n Total of ".$title."\n" ;
	?>
	<?php ob_end_flush(); ?>

