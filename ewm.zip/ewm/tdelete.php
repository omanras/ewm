
<?php

include('header.php');

$table = $_GET['Table'];
$table = $table . $id ;
$table = base64_encode($table) ;
$id3 = $_GET['ID'] ;
$tablename = $_GET['Tablename'] ;



mysqli_query($ConnectDB,"DELETE FROM `$table` WHERE idRow='$id3'") or die(mysqli_error($ConnectDB)); 
echo "<meta http-equiv=\"refresh\" content=\"0; url=texup.php?Table=$tablename&Tablename=$tablename\" />";



?>
 </body>
 </html>
 <?php ob_end_flush(); ?>
