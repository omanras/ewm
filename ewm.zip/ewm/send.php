<?php
include('header.php') ;
?>
<?php /*
<form action="forms.php?Action=AddNew&Table=omx2&Tablename=omx2" name="import" method="post" enctype="multipart/form-data">
<table><tr> <td><b>Message<b></td></tr><tr><td>
name1 :<input type='text' name='name1'/><br /></td></tr>
<tr><td>email2 :<input type='text' name='email2'/><br /></td></tr>
<br /><tr><td><input type="submit" name="submit" value="Submit" /></td></tr>
<table></form>
 </body>
*/

if(isset($_GET)){
$userResveID = $_GET['ID'] ;
$quser=mysqli_query($ConnectDB,"SELECT userName From `users` WHERE userId = '$userResveID'") ;
$quserrow=mysqli_fetch_array($quser);

#echo $quserrow['userName'] ;
#echo '<br>' ;
#}
$userResveID = $_GET['ID'] ;
$msID = $_GET['msID'] ;
$qms = mysqli_query($ConnectDB,"SELECT message,title FROM `message_t` WHERE msID='$msID' AND userResveID='$id2'") ;
$qmsrow = mysqli_fetch_array($qms) ;


if(empty($msID)){
	$title = '' ;
	$mss = '' ;
}
else {
$msID = $_GET['msID'] ;
$title = 'Re :' . $qmsrow['title'] ;
$mss = '"' . $qmsrow['message'] . '"' ; 
}
#echo '<form action="send.php?ID=$userResveID" name="import" method="post" enctype="multipart/form-data">' ;
?>

<form action="send.php?ID=<?php echo $userResveID ?>" name="import" method="post" enctype="multipart/form-data">
<b><h1>Message To : <?php echo $quserrow['userName'] ;?></h1><b><br>
<b><h1>Title : <input type "text"  name="title" value="<?php echo $title ; ?> "/></h1></b>

<h2><textarea style="width:1000px; height:350px;" name="message" >
<?php echo $mss ;?> 
</textarea></h2>

<div id="navbar" class="navbar-collapse collapse">
<ul class="nav navbar-nav">
<input type="submit" name="submit" value="Send" ></a></li>
<ul>
</div>
</form>
</body>
<?php
}
if(isset($_POST["submit"])){
$userResveID = $_GET['ID'] ;
$quser=mysqli_query($ConnectDB,"SELECT * FROM `users` WHERE userId = '$userResveID'") ;
$quserrow=mysqli_fetch_array($quser);
$message = $_POST['message'] ;
$title = $_POST['title'] ;	
$userSendID = $id2 ;
#$userGroupID = '0' ;

#$userGroupID = $quserrow['groupID'] ;
#$userResveID = $userResveID ;

if(empty($message)){
	echo "<h2>No massage was insert </h2>" ;
	echo "<meta http-equiv=\"refresh\" content=\"3; url=$PHP_SELEF\" />";
}
else {
#admin to admin
if($id2 == $id ){
	if($userResveID == $quserrow['groupID']){
		$userGroupID = '0' ;
		$Query = "INSERT INTO message_t(msID,time , userSendID, userGroupID, userResveID,userSentID,message,title) VALUES ('',CURRENT_TIME(),'$userSendID','$userGroupID','$userResveID','','$message','$title') " ;
		mysqli_query($ConnectDB,$Query) ;
		$Query2 = "INSERT INTO message_t(msID,time , userSendID, userGroupID, userResveID,userSentID,message,title) VALUES ('',CURRENT_TIME(),'$userSendID','$userGroupID','$userResveID','$id2','$message','$title') " ;
		mysqli_query($ConnectDB,$Query2) ;
	}
	else{
	if($id == $quserrow['groupID']){
	$userGroupID = $id ;	
	$Query = "INSERT INTO message_t(msID,time , userSendID, userGroupID, userResveID,userSentID,message,title) VALUES ('',CURRENT_TIME(),'$userSendID','$userGroupID','$userResveID','','$message','$title') " ;
	mysqli_query($ConnectDB,$Query) ;
	$Query2 = "INSERT INTO message_t(msID,time , userSendID, userGroupID, userResveID,userSentID,message,title) VALUES ('',CURRENT_TIME(),'$userSendID','$userGroupID','$userResveID','$id2','$message','$title') " ;
	mysqli_query($ConnectDB,$Query2) ;
	}
	else{
		echo "You can only send this massage to the group admin" ;
	}
	}
}

#normal users send only own group 

	

else{
	if($id == $quserrow['groupID']){
	$userGroupID = $id ;	
	$Query = "INSERT INTO message_t(msID,time , userSendID, userGroupID, userResveID,userSentID,message,title) VALUES ('',CURRENT_TIME(),'$userSendID','$userGroupID','$userResveID','','$message','$title') " ;
	mysqli_query($ConnectDB,$Query) ;
	$Query2 = "INSERT INTO message_t(msID,time , userSendID, userGroupID, userResveID,userSentID,message,title) VALUES ('',CURRENT_TIME(),'$userSendID','$userGroupID','$userResveID','$id2','$message','$title') " ;
	mysqli_query($ConnectDB,$Query2) ;
	}
	else{
	echo "<h2>you can't send this massage please send it to your manager <h2> " ;
	}
}

echo "<h2>message was sent<h2>" ;
echo "<meta http-equiv=\"refresh\" content=\"3; url=usersearch.php\" />";
}
}

?>


