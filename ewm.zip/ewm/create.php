<?php
include("header.php") ;
if($id == $id2){
?>
<br>
<br>	
	<b>Create New Table by upload table file , CSV XLSX : </b>
	<td>	<form action="simplexlsx-master/create.php" name="import" method="post" enctype="multipart/form-data">
	
<div class="btn-group">
    	<br><input type="file" button  name="file"  /><br>
		 
		Enter the table name :
		<input type="text" name="table"/><br />
		<div class="btn-group">
       <br> <input type="submit" name="submit" button class="button" value="upload" /></button>
		</div>
		</td>
</form>
		
		
        </div>
        </div>
 <td>	

 
 <b>Create New Table : </b>
 <form action="create.php" name="import" method="post" enctype="multipart/form-data">   

	<td>Enter Table name : <input type="text" name="table"/> </td>
	
	
   <td>  Enter Columns  :   <input type="text" name="col"/> <br>for example : column1,column2,column3,.... 
	
 <br><input type="submit" name="create" button class="button" value="Submit" /></button> </td>
 
 
<?php
#include('include/config.in.php');
//---------------------------------------------------------------------------------------------------

if(isset($_POST['create'])){
	
	$table = $_POST['table'] ;
	$col = $_POST['col'] ;
	if(empty($_POST['table'])){
		echo "<h2>You must Enter table name</h2>" ;
	}
	elseif(empty($_POST['col'])){
		echo "<h2>You must Enter column name</h2>" ;
	}
	else{
	$check = mysqli_query($ConnectDB,"SELECT table_name FROM `files_name` WHERE table_name='$table' AND groupID='$id'") ;
	$check_count = mysqli_num_rows($check) ;
	if($check_count!=0){
	echo "<h2>Can't create table change the name </h2>" ;

	}
	else{
	$table_name="INSERT INTO files_name (table_name,groupID,tableID) VALUES ('$table','$id','')" ;
	$Query = mysqli_query($ConnectDB,"$table_name");
	$tablename = $table ;
	$table = $table .$id ;
	$table = base64_encode($table);
	

	$col = '`' . $col . '`' ;
	$col2 = str_replace(",","` TEXT,`",$col)  ;
	$col2  = $col2 . " TEXT" ;
	echo $col2 ;
	




	mysqli_query($ConnectDB,"CREATE TABLE IF NOT EXISTS `$table` ($col2) ENGINE=MYISAM  DEFAULT CHARSET=utf8");
	$SQL2 ="ALTER TABLE `$table` ADD idRow INT( 7 ) NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST ;" ;
	$Query=mysqli_query($ConnectDB,"$SQL2");
	$SQL3="INSERT INTO timerow (filename,Time,groupID) VALUES ('$tablename',CURRENT_TIME(),'$id')";
	mysqli_query($ConnectDB,"$SQL3");
	echo "<h2>Please wait<h2> " ;
	echo "<meta http-equiv=\"refresh\" content=\"0; url=home.php\" />";
	}
	}

}

?>


</body>
</html>
<?php 
}
ob_end_flush(); ?>