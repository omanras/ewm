<header>
<?php
include("header.php") ;
?>	

<?php

if($id2 == '1'){

$table = $_GET['Table'];
$id = $_GET['ID'] ;



mysqli_query($ConnectDB,"DELETE FROM $table WHERE userId='$id'") or die(mysqli_error($ConnectDB)); 
echo "<meta http-equiv=\"refresh\" content=\"0; url=change.php\" />";
}
else {
	echo "NOT allow " ;
}


?>
 </body>
 </html>
 <?php ob_end_flush(); ?>
