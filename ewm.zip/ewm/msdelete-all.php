<?php
include('header.php');

$table = $_GET['Table'];
$table = $table . $id ;
$table = base64_encode($table) ;
$id3 = $_GET['ID'] ;
$tablename = $_GET['Tablename'] ;
	$idx = $_GET['idx'] ;
	#echo $idx ; 
	
    $delete_id = $_POST['idx'];
	if(empty($delete_id)){
		echo "no data <br>" ;
	}
    $id = count($delete_id);
	#echo $id ;
    if (count($id) > 0) {
        foreach ($delete_id as $id_d) {
           $sql    = "DELETE FROM `message_t` WHERE msID='$id_d' AND userSentID='$id2'";
            $delete = mysqli_query($ConnectDB,$sql);
        }
    }
    if ($delete) {
        echo " <h2>Records deleted Successfully.</h2>";
		echo "<meta http-equiv=\"refresh\" content=\"3; url=sent.php?\" />";
    }


?>