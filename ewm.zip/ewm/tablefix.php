<header>
<?php
include("header.php") ;
?>	


<?php




// get results from database
#$table = $_GET['Table'];
#$result = mysqli_query($ConnectDB,"SELECT * FROM files_name WHERE groupID = '$id'") or die(mysqli_error($ConnectDB));



// display data in table


if($userRow['userId'] == $userRow['groupID']){
echo "<b><h1>Tables</h1></b><br>" ;
echo "<p><a href=\"logs.php\">Show Logs </a></p>";
echo "<table border='1' cellpadding='10'>";
// loop through results of database query, displaying them in the table
#$result3 = mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name ='$table'") ;
$confvalue="return confirm('Are you sure?');";
$confrm = 'onclick='.'"'.$confvalue.'"' ;
$fontdelete ='<center><i class="fa fa-trash"></i></center>' ;
$fontedit='<center><i class="fa fa-pencil"></i></center>' ;
#$result3 = mysqli_query($ConnectDB,"SELECT * FROM files_name WHERE groupID = '$id'") ;

echo '<tr>' ;
echo "<th><center>TABLES</center></th><th><center>Edit</center></th><th><center>Delete</center></th>" ;
$result = mysqli_query($ConnectDB,"SELECT * FROM files_name WHERE groupID = '$id'") or die(mysqli_error($ConnectDB));

	while($tableName = mysqli_fetch_row($result)) {
		$table = $tableName[0];
				/*foreach($tableName as $key=>$Table) {
					if($Table =='users'){
						break ;
					}
					if($Table == 'timerow'){
						break ;
					}
					
				echo "<tr><td><center> $Table </center></td>" ;
				echo "<td><a  href=\"tableedit.php?Table=$Table\">$fontedit </a></td>";
	echo "<td><a href=\"tabledelete.php?Table=$Table\" $confrm>$fontdelete</a></td>";
			}*/
				echo "<tr><td><center> $table </center></td>" ;
				echo "<td><a  href=\"tableedit.php?Table=$table&Tablename=$table\">$fontedit </a></td>";
	echo "<td><a href=\"tabledelete.php?Table=$table&Tablename=$table\" $confrm>$fontdelete</a></td>";

	}


#echo '</tr>';
/*
echo '<th> Edit </th>' ;
echo '<th> Delete </th>' ;
while($row = mysqli_fetch_array($result)) {
	echo '<tr>';

$result2 = mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name ='$table'") ;

if(mysqli_num_rows($result2)) {
	
while($row2 = mysqli_fetch_row($result2)) {

				foreach($row2 as $key=>$value) {
					if($value =='idRow'){
						break ;
					}
				#echo '<th>',$value,'</th>';
				echo '<td><center>' . $row[$value] . '</center></td>';
				
			}	
}
$confvalue="return confirm('Are you sure?');";
$confrm = 'onclick='.'"'.$confvalue.'"' ;
$fontdelete ='<center><i class="fa fa-trash"></i></center>' ;
$fontedit='<center><i class="fa fa-pencil"></i></center>' ;

echo "<td><a  href=\"tedit.php?Table=$table&ID=$row[idRow]\">$fontedit </a></td>";
echo "<td><a href=\"tdelete.php?Table=$table&ID=$row[idRow]\" $confrm>$fontdelete</a></td>";
}

}
*/
echo '</tr>';
echo "</table></div></body>";
echo "<p><a href=\"logs.php\">Show Logs </a></p>";
}
else {
	echo "You Don't have tables to show " ;
}
?>







 <?php #include("footer.php") ;?>

 <?php ob_end_flush(); ?>