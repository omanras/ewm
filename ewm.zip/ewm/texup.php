<header>
<?php
include("header.php") ;
?>	


<?php




// get results from database

#$table = mysqli_real_escape_string($ConnectDB,$_GET['Table']);
echo "<br><br>" ;




// display data in table

if ( isset($_GET['Table'])) {
$table = $_GET['Table'] ;
$tablename=$_GET['Tablename'];

	echo "<b><h1>$table</h1></b><br>" ;
$table = $_GET['Table'] . $id ;
$table = base64_encode($table);
$table = mysqli_real_escape_string($ConnectDB,$table);
$page = 0 ;
if(isset($_GET['page'])){
	$page = $_GET['page'] ;
	if(empty($_GET['page'])) {
	$page = 0 ;
}


}
if(isset($_GET['all'])){
	$result = mysqli_query($ConnectDB,"SELECT * FROM  `$table`") or die(mysqli_error($ConnectDB));
}
else{
$offset = $page * 20 ;
$result = mysqli_query($ConnectDB,"SELECT * FROM  `$table` LIMIT $offset,20") or die(mysqli_error($ConnectDB));
}

?>
<div class="box">
  <div class="container-3">
  <?php
  #echo "<a href=\"sh.php?Table=$table&Tablename=$tablename\">" ;
  echo '<form action="search.php" name = "import" method = "get" > ' ;
  #echo "<form action=\"sh.php?Table=$table\" name=\"import\" method=\"get\" enctype=\"multipart/form-data\">" ;
  echo '<input id="tea-submit" type="hidden" name="Table" value="',$tablename,'">' ;
  #echo '<input id="tea-submit" type="hidden" name="Table" value="',$table,'">' ;
  #$submit = 'value = ' . '"' .$table .'"' ;
  #echo '<input id="tea-submit" type="hidden" name="Table" ',$submit,'>' ;
  ?>
  
    <span class="icon"><i class="fa fa-search"></i></span>
	   
      <input type="search" name="search" id="search" placeholder="Search..." /> 
	 </form>
  </div>
 <?php 
echo "<form action = \"delete-all.php?Table=$tablename&Tablename=$tablename\" method=\"POST\">" ;	
?>
<tr><td><input type="submit" name="delete"  value="Delete selected value" style="float:right;" onclick="return confirm('Are you sure?');"/></td></tr> 
 
</div>
<br>
<br>
<br>
<br>
<?php	

$rowcount=mysqli_num_rows($result);

$styel = 'style="float:right;"' ;
#if($rowcount >= 20) {
	

if( $page > 0 ) {
	
	$next = $page + 1 ;
    $last = $page - 1 ;
	if($rowcount >= 20) {
	echo  "<a href = \"$_PHP_SELF?Table=$tablename&Tablename=$tablename&all\" $styel> Show All </a>";
	echo "<a href = \"$_PHP_SELF?Table=$tablename&Tablename=$tablename&page=$next\" $styel> Next  Record | </a>";	
	}
    echo "<a href = \"$_PHP_SELF?Table=$tablename&Tablename=$tablename&page=$last\" $styel> Last  Record | </a> ";
	}
    
 else if( $page == 0 ) {
	 if($rowcount >= 20) {
   # $page = $page + 1;
   $last = $page + 1 ;
    echo  "<a href = \"$_PHP_SELF?Table=$tablename&Tablename=$tablename&all\" $styel> Show All </a>";
	echo "<a href = \"$_PHP_SELF?Table=$tablename&Tablename=$tablename&page=$last\" $styel> Next  Record | </a>";
	 }
 }else if( $left_rec < $rec_limit ) {
    $last = $page - 2;
    echo  "<a href = \"$_PHP_SELF?Table=$tablename&Tablename=$tablename&all\" $styel> Show All </a>";
	echo "<a href = \"$_PHP_SELF?Table=$tablename&Tablename=$tablename&page=$next\" $styel> Next  Record | </a>";
 }
#}
echo "<p><a href=\"forms.php?Table=$tablename\">Add a new record</a></p>";
$act = "delete-all.php?Table=$tablename&Tablename=$tablename" ;



#echo '<center><input type="submit" name="delete"  value="Delete" /></center> ';
echo "<table border='1' cellpadding='10'>";

// loop through results of database query, displaying them in the table
#$result3 = mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name ='$table'") ;
$result3=mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$table'");
while($row3 = mysqli_fetch_row($result3)){
	
	foreach($row3 as $key=>$value) {
		if($value =='idRow'){
			break ;
		}
	echo '<th>',$value,'</th>';
	
}
 
}


echo '<th> Edit </th>' ;
echo '<th> Delete </th>' ;
echo '<th><center> * </center></th>' ;

while($row = mysqli_fetch_array($result)) {
	echo '<tr>';

$result2 = mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name ='$table'") ;

if(mysqli_num_rows($result2)) {

while($row2 = mysqli_fetch_row($result2)) {



				foreach($row2 as $key=>$value) {
					if($value =='idRow'){
						break ;
					}
				#echo '<th>',$value,'</th>';
				echo '<td><center>' . $row[$value] . '</center></td>';
				
			}	
}
$confvalue="return confirm('Are you sure?');";
$confrm = 'onclick='.'"'.$confvalue.'"' ;
$fontdelete ='<center><i class="fa fa-trash"></i></center>' ;
$fontedit='<center><i class="fa fa-pencil"></i></center>' ;

echo "<td><a  href=\"tedit.php?Table=$tablename&ID=$row[idRow]\">$fontedit </a></td>";
echo "<td><a href=\"tdelete.php?Table=$tablename&Tablename=$tablename&ID=$row[idRow]\" $confrm>$fontdelete</a></td>";
$idRow = $row['idRow'] ;
echo "<td><center><input type=\"checkbox\" name=\"idx[]\" value=\"$idRow\" /></center></td>" ;

#<td><input type="checkbox" name="idx[]" value="<?php echo $row['idRow']; " /></td>
 
}

}
echo '</tr>';


echo "</table></div></body>";
#echo "<a name=".'delete'." href=\"delete-all.php?Table=$tablename&Tablename=$tablename&ID=$row[idRow]\" $confrm>delete selected value </a>";
#echo '<center><input type="submit" name="delete"  value="Delete" /></center></form>';
if( $page > 0 ) {
	
	$next = $page + 1 ;
    $last = $page - 1 ;
	if($rowcount >= 20) {
	echo  "<a href = \"$_PHP_SELF?Table=$tablename&Tablename=$tablename&all\" $styel> Show All </a>";
	echo "<a href = \"$_PHP_SELF?Table=$tablename&Tablename=$tablename&page=$next\" $styel> Next  Record | </a>";	
	}
    echo "<a href = \"$_PHP_SELF?Table=$tablename&Tablename=$tablename&page=$last\" $styel> Last  Record | </a> ";
	}
    
 else if( $page == 0 ) {
	 if($rowcount >= 20) {
   # $page = $page + 1;
   $last = $page + 1 ;
    echo  "<a href = \"$_PHP_SELF?Table=$tablename&Tablename=$tablename&all\" $styel> Show All </a>";
	echo "<a href = \"$_PHP_SELF?Table=$tablename&Tablename=$tablename&page=$last\" $styel> Next  Record | </a>";
	 }
 }else if( $left_rec < $rec_limit ) {
    $last = $page - 2;
    echo  "<a href = \"$_PHP_SELF?Table=$tablename&Tablename=$tablename&all\" $styel> Show All </a>";
	echo "<a href = \"$_PHP_SELF?Table=$tablename&Tablename=$tablename&page=$next\" $styel> Next  Record | </a>";
 }
echo "<p><a href=\"forms.php?Table=$tablename\">Add a new record</a></p>";
}
?>







 <?php #include("footer.php") ;?>

 <?php ob_end_flush(); ?>