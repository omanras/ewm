

<header>
<?php
include("header.php") ;
?>	
</header>


 
 <?php
 

#$table = 'idrow4';
$table = $_GET['Table'] ;

$tablename = $_GET['Table'];
$table = $table . $id ;
$table = base64_encode($table);
//---------------------------------------------------------------------------------------------------
		echo "<h1>Add New Info In To Table ($tablename) :</h1><br/>";
		echo "<form action=\"forms.php?Action=AddNew&Table=$tablename&Tablename=$tablename\" name=\"import\" method=\"post\" enctype=\"multipart/form-data\">" ;
		echo "<table>";

#$Query = mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name ='$table'") ;
$Query=mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$table'");
$Check=mysqli_num_rows($Query);
	if($Check >0) {
		
		while($Row = mysqli_fetch_row($Query)) {

			$b = array();
			$count2 = 0 ;
			$data2 = '' ;
			
			foreach($Row as $key=>$value) {
				if($value == 'idRow'){
					break ;
				}
				$b[$count2] = "<tr><td><b>$value :</b></td></tr> <td><input type='text' name='$value'/></td></tr>" ;
				$data2 = $b[$count2]  ;

				echo "$data2" ; 
				error_reporting(0);
				
				
			}

		}

		
	}
	echo '<br />';
		#echo '<tr><td><input type="submit" name="submit" value="Submit" /></td></tr><table></form>';
		echo '<tr><td><input type="submit" name="submit" value="save" />     <input type="submit" name="add"  value="save and add" /></td></tr></table></form>';
		
//---------------------------------------------------------------------------------------------------		

if($_GET[Action]==AddNew){
		
		#$table =$_GET['TableName'];
        $tablename = $_GET['Tablename'];
		$table = $_GET['Tablename'] . $id ;
		$table = base64_encode($table);
		$a = array() ;
		$count = 0 ;
		$data='';
			foreach($_POST as $key => $val){
			if($val!='save' && $val != 'save and add'){
				$a[$count] = $val ;
				$data=$data."'$a[$count]'".",";
		   	    
			}
			$count++ ;
	   }		
		$sqlinsert=substr($data,0,-1);

		$Sql_Query = "INSERT INTO `$table`  VALUES ('',$sqlinsert)" ;
		#echo $Sql_Query ; 
		#idrow7 VALUES ('','dd','ddddddd')inserted
		#INSERT INTO sami VALUES ('abc','def','')inserted

		$QueryRes=mysqli_query($ConnectDB,$Sql_Query);
		
		if($QueryRes){
			echo "<h2>inserted<h2>";
		}else{
			echo "<h2>there is error<h2>";	
		}
		if(isset($_POST['add'])){
			echo "<meta http-equiv=\"refresh\" content=\"3; url=forms.php?Table=$tablename\" />" ;
		}
		else{
		echo "<meta http-equiv=\"refresh\" content=\"3; url=texup.php?Table=$tablename&Tablename=$tablename\" />";
}	}
//---------------------------------------------------------------------------------------------------			
	?>

 </body>
<footer>
 <?php #include("footer.php") ;?>
 </footer>
  <?php ob_end_flush(); ?>