<?php
include('header.php') ;
?>
<?php /*
<form action="forms.php?Action=AddNew&Table=omx2&Tablename=omx2" name="import" method="post" enctype="multipart/form-data">
<table><tr> <td><b>Message<b></td></tr><tr><td>
name1 :<input type='text' name='name1'/><br /></td></tr>
<tr><td>email2 :<input type='text' name='email2'/><br /></td></tr>
<br /><tr><td><input type="submit" name="submit" value="Submit" /></td></tr>
<table></form>
 </body>
*/

if(isset($_GET)){
$userResveID = $_GET['ID'] ;
$quser=mysqli_query($ConnectDB,"SELECT * FROM `users` WHERE userId = '$userResveID'") ;
$quserrow=mysqli_fetch_array($quser);
#echo $quserrow['userName'] ;
#echo '<br>' ;
#}
$userResveID = $_GET['ID'] ;
#echo '<form action="send.php?ID=$userResveID" name="import" method="post" enctype="multipart/form-data">' ;
?>

<form action="sendgroup.php?ID=<?php echo $userResveID ?>" name="import" method="post" enctype="multipart/form-data">
<b><h1>Brodcast group   name :  <?php echo $userRow['groupName'] ;?></h1><b><br>
<b><h1>Title : <input type "text"  name="title"/></h1></b>

<h2><textarea style="width:1000px; height:350px;" name="message" >
</textarea></h2>
<br>
<div id="navbar" class="navbar-collapse collapse">
<ul class="nav navbar-nav">
<input type="submit" name="submit" value="Send" ></a></li>
<ul>
</div>
</form>
</body>
<?php
}
if(isset($_POST["submit"])){
$userResveID = '';
$quser=mysqli_query($ConnectDB,"SELECT userId FROM `users` WHERE groupId = '$id'") ;
$quserrow=mysqli_fetch_array($quser);
$message = $_POST['message'] ;
$title = $_POST['title'] ;	
$userSendID = $id2 ;
$userGroupID = $id ;
#$userResveID = $userResveID ;

 
while($Row = mysqli_fetch_row($quser)) {

			$b = array();
			$count2 = 0 ;
			$data2 = '' ;
			
			foreach($Row as $key=>$value) {
				if($value == 'idRow'){
					break ;
				}
				$b[$count2] = "$value" ;
				$data2 = $b[$count2]  ;
				#$data2 = substr($data2,0,-1);
				$Query="INSERT INTO `message_t` (msID,time , userSendID, userGroupID, userResveID,userSentID,message,title) VALUES ('',CURRENT_TIME(),'$userSendID','$userGroupID','$data2','','$message','$title')"  ; 
				mysqli_query($ConnectDB,$Query) ;
				error_reporting(0);
				
				
			}
		$count2++ ;
		}

$Query="INSERT INTO `message_t` (msID,time , userSendID, userGroupID, userResveID,userSentID,message,title) VALUES ('',CURRENT_TIME(),'$userSendID','$userGroupID','$id2','','$message','$title')"  ; 
mysqli_query($ConnectDB,$Query) ;
$Query2="INSERT INTO `message_t` (msID,time , userSendID, userGroupID, userResveID,userSentID,message,title) VALUES ('',CURRENT_TIME(),'$userSendID','$userGroupID','','$id2','$message','$title')"  ; 
mysqli_query($ConnectDB,$Query2) ;
echo "<meta http-equiv=\"refresh\" content=\"3; url=usersearch.php\" />";

}

?>


