<?php
	ob_start();
	session_start();
	#require_once 'dbconnect.php';
	include('config.php');
	// if session is not set this will redirect to login page
	
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}

	// select loggedin users detail
	$res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
	$userRow=mysql_fetch_array($res);
	$id = $userRow['groupID'] ;
	$id2 = $userRow['userId'] ;
	$username = $userRow['userName'] ; 
	$groupname = $userRow['groupName'];
?>

<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html>
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
	
      
<title>Welcome - <?php echo $username ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="table.css" type="text/css" />
	<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.css">


	</head>

	
	
	
	
	
<style>

input[type=text], select {
    width: 30%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}
select {
    
    padding: 16px 20px;
    border: none;
    border-radius: 4px;
    background-color: #f1f1f1;
}

</style>
	
	
	
	
	
	
<body>	
<nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="../group/home.php">HOME</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
		  
		  <?php if($id == $id2){ ?>
            <li class="active"><a href="tablefix.php">Tables settings </a></li>
		  <?php } ?>
<?php
//---------------------------------------------------------------------------------------------------
#echo '<div class="btn-group"><br><br><table><tr><td><b> Table </b></td></tr>';

$button = '<button class="button">';
$tableq= "SELECT * FROM files_name WHERE groupID = '$id'" ;
#$result = mysqli_query($ConnectDB,'SHOW TABLES') or die(mysqli_error($ConnectDB));
$result = mysqli_query($ConnectDB,$tableq) or die(mysqli_error($ConnectDB));
#$tableRow=mysqli_fetch_array($result);
#$Table = $tableRow['table_name'] ;
#echo "<li><a href=\"texup.php?Table=$Table\"> $Table </a></li>" ;
	while($tableName = mysqli_fetch_array($result)) {
		$table = $tableName[0];
		echo  "<li><a href=\"texup.php?Table=$table&Tablename=$table\"> $table </a></li>" ;
		#echo $tableRow['table_name'] ;
			/*	foreach($tableName as $key=>$Table) {
					if($Table =='groupID'){
						break ;
					}
				#echo $Table['table_name'];
				#echo "<li><a href=\"texup.php?Table=$Table\"> $Table </a></li>" ;
			}*/
		

	}

#echo '</table></div>' ;

//---------------------------------------------------------------------------------------------------

?>
            
          </ul>
          <ul class="nav navbar-nav navbar-right">
            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $username; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
			  
			  
			  <?php if($id == $id2){ ?>
			  <li><a href="usersend.php"><span class="icon"><i class="fa fa-inbox"></i></span>&nbsp;Send message  </a></li>
			  <li><a href="inbox.php"><span class="icon"><i class="fa fa-box"></i></span>&nbsp;Inbox  </a></li>
			  <li><a href="sent.php"><span class="icon"><i class="fa fa-email"></i></span>&nbsp;Sent Box  </a></li>
				<li><a href="register.php"><span class="icon"><i class="fa fa-user-circle"></i></span>&nbsp;Register New Account  </a></li>
				<li><a href="userchange.php"><span class="icon"><i class="fa fa-cog"></i></span>&nbsp;Accounts Group Manage  </a></li>
				<li><a href="create.php"><span class="icon"><i class="fa fa-edit"></i></span>&nbsp;Create Table  </a></li>
				<?php 
			  }
			  else{
				  echo '<li><a href="usersearch.php"><span class="icon"><i class="fa fa-inbox"></i></span>&nbsp;Send message  </a></li>' ;
				  echo '<li><a href="inbox.php"><span class="icon"><i class="fa fa-box"></i></span>&nbsp;Inbox  </a></li>';
				 echo ' <li><a href="sent.php"><span class="icon"><i class="fa fa-email"></i></span>&nbsp;Sent Box  </a></li> ';
			  }
				if($id2 == '1'){
					?>
				<li><a href="admin-register.php"><span class="icon"><i class="fa fa-cog"></i></span>&nbsp;Create New group  </a></li>
				<li><a href="change.php"><span class="icon"><i class="fa fa-cog"></i></span>&nbsp;Accounts Manage  </a></li>
				<?php } ?>
				<li><a href="usersetting.php"><span class="icon"><i class="fa fa-user-circle"></i></span>&nbsp;My Setting  </a></li>
				<li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 

<script src="assets/jquery-1.11.3-jquery.min.js"></script>
 <script src="assets/js/bootstrap.min.js"></script>
 <div id="wrapper">

<div class="container">
<div class="page-header">
 