<?php 
include('header.php') ;
?>
<?php
if($id2 == $id){

$table = $_GET['Table'];
$id3 = $_GET['ID'] ;



mysqli_query($ConnectDB,"DELETE FROM $table WHERE userId='$id3' AND groupID='$id' ") or die(mysqli_error($ConnectDB)); 
echo "<meta http-equiv=\"refresh\" content=\"0; url=usersetting.php\" />";
}
else{
	echo "NOT allow" ;
}
?>