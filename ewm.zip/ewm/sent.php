<header>
<?php
include("header.php") ;
?>	


<?php




// get results from database

#$table = mysqli_real_escape_string($ConnectDB,$_GET['Table']);





// display data in table


$table = 'message_t' ;
$table = mysqli_real_escape_string($ConnectDB,$table);
$result = mysqli_query($ConnectDB,"SELECT * FROM `$table` WHERE userSendID = '$id2' AND userSentID='$id2'") or die(mysqli_error($ConnectDB));

?>
<div class="box">
  <div class="container-3">
  
  </div>
   <?php 
echo "<form action = \"msdelete-all.php\" method=\"POST\">" ;	
?>

</div>

<?php	


echo '<b><h1>Sent box</h1></b>';
?>
<tr><td><input type="submit" name="delete"  value="Delete selected value" style="float:right;" onclick="return confirm('Are you sure?');"/></td></tr>
<br>
<?php
echo "<p><a href=\"usersearch.php\">Send message</a></p>";
echo "<table border='1' cellpadding='10'>";
// loop through results of database query, displaying them in the table
#$result3 = mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name ='$table'") ;
$result3=mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$table'");
while($row3 = mysqli_fetch_row($result3)){
	
	foreach($row3 as $key=>$value) {
		if($value =='msID'){
			break ;
		}
		if($value =='message'){
						break ;
					}
					if($value == 'userGroupID'){
						break ;
					}
					if($value == 'userResveID'){
						echo "<th>To</th>" ;
						break ;
					}
					if($value == 'userSentID'){
						break ;
					}
					if($value == 'userSendID'){
						#break;
						echo '<th>From</th>';
						break ;
					}
	echo '<th>',$value,'</th>';
	
}
 
}
echo '<th> Show </th>' ;
echo '<th> Delete </th>' ;
echo '<th><center>*</center></th>' ;
while($row = mysqli_fetch_array($result)) {
	echo '<tr>';

$result2 = mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$table'") ;

if(mysqli_num_rows($result2)) {
	
while($row2 = mysqli_fetch_row($result2)) {

				foreach($row2 as $key=>$value) {
					if($value == 'msID'){
						break ;
					}
					if($value =='message'){
						break ;
					}
					if($value == 'userGroupID'){
						break ;
					}
					if($value == 'userResveID'){
						#echo $row[$value] ;
						$quser=mysqli_query($ConnectDB,"SELECT * FROM `users` WHERE userId = '$row[$value]'") ;
						$quserrow=mysqli_fetch_array($quser);
						echo '<td><center>' . $quserrow['userName'] . '</center></td>';
						
						break ;
					}
					
					if($value == 'userSentID'){
						break ;
					}
					if($value == 'userSendID'){
						$quser=mysqli_query($ConnectDB,"SELECT * FROM `users` WHERE userId = '$row[$value]'") ;
						$quserrow=mysqli_fetch_array($quser);
						echo '<td><center>' . $quserrow['userName'] . '</center></td>';
						break ;
					}
					
				#echo '<th>',$value,'</th>';
				echo '<td><center>' . $row[$value] . '</center></td>';
				
			}	
}
$confvalue="return confirm('Are you sure?');";
$confrm = 'onclick='.'"'.$confvalue.'"' ;
$fontdelete ='<center><i class="fa fa-trash"></i></center>' ;
$fontedit='<center><i class="fa fa-envelope"></i></center>' ;
$user = $quserrow['userName'] ;
echo "<td><a  href=\"showsent.php?ID=$row[msID]&user=$user&userID=$row[userSendID]\">$fontedit </a></td>";
echo "<td><a href=\"mssent-delete.php?ID=$row[msID]\" $confrm>$fontdelete</a></td>";
echo "<td><center><input type=\"checkbox\" name=\"idx[]\" value=\"$row[msID]\" /></center></td>" ;
}

}
echo '</tr>';
echo "</table></div></body>";
echo '</form>' ;
echo "<p><a href=\"usersearch.php\">Send message</a></p>";

?>







 <?php #include("footer.php") ;?>

 <?php ob_end_flush(); ?>