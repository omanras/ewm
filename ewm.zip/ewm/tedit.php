<header>
<?php
include("header.php") ;
?>	
</header>


<?php


$table = $_GET['Table'];
$id3 = $_GET['ID'] ;
$tablename=$_GET['Table'];
$table = $table.$id ;
$table = base64_encode($table) ;
if (isset($_GET['ID']) && is_numeric($_GET['ID']) && $_GET['ID'] > 0){

$result = mysqli_query($ConnectDB,"SELECT * FROM `$table` WHERE idRow='$id3'") or die(mysqli_error($ConnectDB)); 

//echo "$result dd";

echo "<b><h1> You edit ID $id3 in table : $tablename</h1></b><br>" ;
#echo "<table><tr> <td><b>In Table $tablename<b></td></tr>";
#echo '<form name="import" method="post" enctype="multipart/form-data">' ;

echo "<table><form action=\"tedit.php?Action=AddNew&Table=$tablename&Tablename=$tablename&ID=$id3\" name=\"import\" method=\"post\" enctype=\"multipart/form-data\">" ;
while($row = mysqli_fetch_array($result)) {
if(mysqli_num_rows($result)) {
	
#$table = $_GET['Table'] . $id ;
#$table = base64_encode($table);
#$table = mysqli_real_escape_string($ConnectDB,$table);

$result2 = mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name ='$table'") ;		

while($row2 = mysqli_fetch_row($result2)) {
			
			    
					
				
				foreach($row2 as $key=>$value) {
				#echo '<th>',$value,'</th>';
				#echo '<td>',$value,'</td>';
				if($value == "idRow"){
					break ;
					
				}
				$value2 = base64_encode($value) ;
				#echo '<tr><td><strong>'.$value.'</strong> <input type="text" name="'.$value.'" value="'.$row[$value].'"/></td></tr>' ;
				echo "<tr><td><b>$value :</b></tr></td><td><input type='text' name='$value2'  value='$row[$value]'/><br /></td></tr>" ;
				#echo "<tr><td>$value :<input type='text' name='$value'/><br /></td></tr>" ;
				
}

}

}
#echo '<br>' ;
echo '<td><input type="submit" name="submit" value="Submit" /></form></td></table>';
}
}
?>
<?php

if(isset($_POST["submit"])){
$result2 = mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name ='$table'") ;
$row = $_POST ;
foreach($row as $key => $val){
	#key = base64_decode($key) ;
	if($key == 'submit'){
		break ;
	}
	$key = base64_decode($key) ;
	$Query = "UPDATE `$table` SET `$key` = '$val' WHERE idRow = '$id3' ;" ;
	$Query=mysqli_query($ConnectDB,$Query) ;
}
#echo "UPDATE `$table` SET `$key` = `$val` WHERE idRow = '$id3'" ;
if($Query){
					echo "<h2>updated</h2>";
				}
				else{
					echo "<h2>Not updated<h2>";
				}

echo "<meta http-equiv=\"refresh\" content=\"3; url=texup.php?Table=$tablename&Tablename=$tablename\" />";
	}

?>
 </body>
 <footer>

 </footer>
 </html>
 <?php ob_end_flush(); ?>
