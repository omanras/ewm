<?php 
#include('config.php') ;

?>

<html><body> 
<form action="install-user.php" method="POST">
<h2>
Welcome to "Excel Web Manager v 0.1 Beta " , first of all the terms of use this program not to use
this program in any unethical things . This program is beta version so the programmer is not responsible in
any security problems . 

If you click "Next" you are agree about this terms .  
<br>
<br>
NOTE : "Please enter the database information in 'config.php' before cilck 'Next'" 

</h2>
<br>
<center><input type="submit" name="agree" value="Next" /></center></form>