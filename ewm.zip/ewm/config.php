<?php
/*
.---------------------------------------------------------------------------.
|  Software: Excel Web Manager 2010-2017 					                        	|
|   Version: 0.1 Beta 
|	programmer : Majid Almmashari | email : omanras@gmail.com                                                         	|
'---------------------------------------------------------------------------'
*/
if (preg_match("/config.php/i",$_SERVER['SCRIPT_NAME'])) {die ("FictionX Protact This Web Site ...");} 
error_reporting(0);
/*------------------------------------------------------------------------------------*/

$DBhost = "";  	// your database hostname
$DBname = "";  		// your database name
$DBusername = ""; 		// your database username
$DBpassword = "";    	// your database password  



/*------------------// Create DataBase Connection //----------------------------------*/
$database = $DBname ;
$ConnectDB= mysqli_connect($DBhost,$DBusername,$DBpassword,$DBname);
$conn = mysql_connect($DBhost,$DBusername,$DBpassword);
$dbcon = mysql_select_db($DBname);
#mysqli_query( $ConnectDB, 'SET NAMES "utf8" COLLATE "utf8_general_ci"' );
mysqli_set_charset($ConnectDB,'utf8');

//filter the POST and GET from exploits

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
     
	 
	 foreach($_GET as $key => $val){
		#echo "<script>alert('$key : $val');</script>"	;
		 $_GET[$key] = htmlspecialchars($_GET[$key]) ;
		 
		 $_GET[$key] = mysqli_real_escape_string($ConnectDB,$_GET[$key]);
		 
	 }
	 
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
     
	 
	 foreach($_POST as $key => $val2){
		
		if($key == 'idx'){
			break ;
		}
		
		
		#echo "<script>alert('$key : $val2');</script>"	;
		$_POST[$key] = htmlspecialchars($_POST[$key]) ;
				 
		$_POST[$key] = mysqli_real_escape_string($ConnectDB, $_POST[$key]);
		
		
	 }
}

?>