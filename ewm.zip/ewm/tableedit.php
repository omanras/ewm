
<header>
<?php
include("header.php") ;
?>	
</header>

<body>	
<table>
<td>
<?php
if($id == $id2){

$tablename=$_GET['Tablename'] ;
$table = $_GET['Table'];
$table = $table . $id ;
$table = base64_encode($table);
#$id = $_GET['ID'] ;

if (isset($_GET['Table'])){
	#RENAME TABLE old_table TO new_table;
	#$result = mysqli_query($ConnectDB,"SELECT * FROM `$table` WHERE idRow='$id'") or die(mysqli_error($ConnectDB)); 
	echo "<b>You Edit : $tablename </b><br>" ;
	echo '<form name="import" method="post" enctype="multipart/form-data">' ;
	echo 'Rename Table : <input type="text" name="table2" value="'.$tablename.'"/><br/>' ;
	echo '<br>' ;
	
	#ADD column Befor/After  | ALTER TABLE `users` ADD `ss` INT NOT NULL AFTER `userPass`;
	$result = mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$table'") or die('cannot show tables');
	echo '<b>Add Column :</b><br> Column Name : <input type="text" name="columnname" />' ;
	echo ' Add column After : <select name="Column">';
	echo '<option value="First">First</option>' ;
	while($column = mysqli_fetch_row($result)) {
	$col = $column[0];
	
	foreach($column as $key=>$value) {
	#echo '<h3>',$table,'</h3>';
	if($value =='idRow'){
		break ;
	}
	echo '<option value="',$value,'">',$value,'</option>' ;
	}
	

	}
	echo '</select>' ;
	echo '<br><input type="submit" name="submit" value="Submit" /></form>';
	#Rename column 
	echo '<form name="import" method="post" enctype="multipart/form-data">' ;
	$result = mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$table'") or die('cannot show tables');
	
	echo '<br><br> <b>Rename column : </b><select name="renamecolumn"> ' ;
	while($column = mysqli_fetch_row($result)) {
	$col = $column[0];
	
	foreach($column as $key=>$value) {
	#echo '<h3>',$table,'</h3>';
	if($value =='idRow'){
		break ;
	}
	echo '<option value="',$value,'">',$value,'</option>' ;
	}
	

	}
	echo '</select> To : <input type="text" name="colname" />';
	echo '<br><input type="submit" name="Rename" value="Rename" /></form>';
	
	#Delete column 
	echo '<form name="import" method="post" enctype="multipart/form-data">' ;
	$result = mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$table'") or die('cannot show tables');
	
	echo '<br><br> <b>Delete column : </b><select name="deletecolumn">';
	while($column = mysqli_fetch_row($result)) {
	$col = $column[0];
	
	foreach($column as $key=>$value) {
	#echo '<h3>',$table,'</h3>';
	if($value =='idRow'){
		break ;
	}
	echo '<option value="',$value,'">',$value,'</option>' ;
	}
	

	}
	echo '</select>' ;
	echo '<br><input type="submit" name="delete" value="Delete" /></form>';
	if(isset($_POST["submit"])){
		$table2= $_POST['table2'] ;
		$column = $_POST['Column'] ;
		$columnname = $_POST['columnname'] ;
if($tablename != $table2) {
$check = mysqli_query($ConnectDB,"SELECT table_name FROM `files_name` WHERE table_name='$table2' AND groupID='$id'") ;
$check_count = mysqli_num_rows($check) ;

if($check_count!=0){
	echo "<h2>This name ready used  </h2>" ;

}
else {
		#"UPDATE `$table` SET $value='$row[$data2]' WHERE idRow='$id'"
		mysqli_query($ConnectDB,"UPDATE files_name SET table_name ='$table2' WHERE table_name='$tablename' AND groupID = '$id' ") ;
		#$table = $_GET['Table'];
		$table2 = $table2 . $id ;
		$table2 = base64_encode($table2);
		mysqli_query($ConnectDB,"RENAME TABLE `$table` TO `$table2`");
}

}

	
		if(isset($_POST['columnname'])){
		$table2= $_POST['table2'] ;
		$table2 = $table2 . $id ;
		$table2 = base64_encode($table2);
		$column = $_POST['Column'] ;
		$columnname = $_POST['columnname']; 
			if($column == 'First'){
						mysqli_query($ConnectDB,"ALTER TABLE `$table2` ADD `$columnname` TEXT NOT NULL AFTER `idRow`") ;

			}
		mysqli_query($ConnectDB,"ALTER TABLE `$table2` ADD `$columnname` TEXT NOT NULL AFTER `$column`") ;
		
		}
		echo "<h2>Please wait </h2>" ;
				echo "<meta http-equiv=\"refresh\" content=\"3; url=$PHP_SELEF\" />";	

	}
	#RENAME column | ALTER TABLE `dgvzdcb0ywjszte=` CHANGE `note` `notex` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
	if(isset($_POST['Rename'])){
		$column = $_POST['renamecolumn'] ;
		$colname = $_POST['colname'] ;
		if(empty($colname)){
			echo "<h2>Please Enter column name </h2>" ;
		}
		else{
		mysqli_query($ConnectDB,"ALTER TABLE `$table` CHANGE `$column` `$colname` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL") ;
		echo "<h2>Please wait </h2>" ;
				echo "<meta http-equiv=\"refresh\" content=\"3; url=$PHP_SELEF\" />";
		}
	}
		#Delete column | "ALTER TABLE `pentest` DROP `company_name`";
		if(isset($_POST['delete'])){
			$column = $_POST['deletecolumn'] ;
			mysqli_query($ConnectDB,"ALTER TABLE `$table` DROP `$column`") ;
			echo "<h2>Please wait </h2>" ;
				echo "<meta http-equiv=\"refresh\" content=\"3; url=tablefix.php\" />";

		}

echo '</td>' ;		
#Replace column | ALTER TABLE `table_name` MODIFY `column_you_want_to_move` DATATYPE AFTER `column`

	$result = mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$table'") or die('cannot show tables');
	echo '<form name="import" method="post" enctype="multipart/form-data">' ;
	echo '<td><br><b>Replace Column : </b><select name="colone">'	;
	echo '<option value="First">Select column</option>' ;
	while($column = mysqli_fetch_row($result)) {
	$col = $column[0];
	
	foreach($column as $key=>$value) {
	#echo '<h3>',$table,'</h3>';
	
	if($value =='idRow'){
		break ;
	}
	echo '<option value="',$value,'">',$value,'</option>' ;
	}
	

	}
	echo '</select>' ;
	echo ' After column  : <select name="coltwo">';
	
	$result = mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$table'") or die('cannot show tables');
	while($column = mysqli_fetch_row($result)) {
	$col = $column[0];
	
	foreach($column as $key=>$value) {
	#echo '<h3>',$table,'</h3>';
	if($value =='idRow'){
		break ;
	}
	echo '<option value="',$value,'">',$value,'</option>' ;
	}
	

	}
	echo '</select>' ;
	echo '<br><input type="submit" name="Replace" value="Replace" /></form>';
	if(isset($_POST['Replace'])){
		#ALTER TABLE `table_name` MODIFY `column_you_want_to_move` DATATYPE AFTER `column`
		$colone = $_POST['colone'] ;
		$coltwo = $_POST['coltwo'] ;
		if($colone == 'First'){
			echo "<h2>Please select column </h2>" ;
		}
		else{
			mysqli_query($ConnectDB,"ALTER TABLE `$table` MODIFY `$colone` TEXT AFTER `$coltwo`") ;
			echo "<h2>Please wait </h2>" ;
			echo "<meta http-equiv=\"refresh\" content=\"0; url=$PHP_SELEF\" />";
		}
	}

#upload csv files to tables 

echo "<br><br><b>Upload data to , only CSV : $tablename </b>";
echo '<form name="import" method="post" enctype="multipart/form-data">' ;
	$result = mysqli_query($ConnectDB,"SELECT table_name FROM `files_name` WHERE groupID='$id'") or die('cannot show');
	
	echo '<br><input type="file" button  name="file"  />' ;
	echo '<br><br><input type="submit" name="insert" value="upload" /></form>';
echo '</td></table></div>' ;
if(isset($_POST['insert'])){
	$file = file_get_contents($_FILES['file']['tmp_name']);
	$file = iconv('WINDOWS-1256', 'UTF-8', $file);
	file_put_contents($_FILES['file']['tmp_name'], $file);
	$file = $_FILES['file']['tmp_name']; ;

	// get structure from csv and insert db
	ini_set('auto_detect_line_endings',TRUE);
	$handle = fopen($file,'r');
	// first row, structure
	if ( ($data = fgetcsv($handle) ) === FALSE ) {
    echo "Cannot read from csv $file";
	die();
}
$fields = array();
print_r($fields);
$field_count = 0;
for($i=0;$i<count($data); $i++) {
    $f = strtolower(trim($data[$i]));
    if ($f) {
        // normalize the field name, strip to 20 chars if too long
        #$f = substr(preg_replace ('/[^0-9a-z]/', '_', $f), 0, 20);
        $field_count++;
        #$fields[] = "`$f`".' VARCHAR(255)';
		$fields[] = "`$f`".' TEXT';
    }
}
$FieldsToAdd=implode(',', $fields);

while ( ($data = fgetcsv($handle) ) !== FALSE ) {
    $fields = array();
    for($i=0;$i<$field_count; $i++) {
        $fields[] = '\''.addslashes($data[$i]).'\'';
    }
	$CSVDATA=implode(',',$fields);
	
    $SQL = "INSERT INTO  `$table` VALUES ('',$CSVDATA)";
	$Query=mysqli_query($ConnectDB,$SQL) or die(mysqli_error($ConnectDB));
	#echo $SQL; 
	
}

fclose($handle);
ini_set('auto_detect_line_endings',FALSE);
#echo $SQL ;
echo "<h2>Please wait </h2>" ;
echo "<meta http-equiv=\"refresh\" content=\"0; url=home.php\" />";
}	
}
}

else{
	echo "NOT ALLOW" ;
}
?>
 </body>
 <footer>
 <?php include("footer.php") ;?>
 </footer>
 </html>
 <?php ob_end_flush(); ?>
