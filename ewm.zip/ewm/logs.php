<?php
include("header.php") ;
if($id == $id2){
?>
<?php
$table = 'timerow';
// get results from database
#$table = $_GET['Table'];
$result = mysqli_query($ConnectDB,"SELECT filename,Time FROM $table  WHERE groupID = '$id'") or die(mysqli_error($ConnectDB));



// display data in table




echo "<b><h1>Logs</h1></b><br>" ;
echo "<table border='1' cellpadding='10'>";
echo "<th><center>Table name </center></th>" ;
echo "<th><center> Time </center></th>" ;
while($row = mysqli_fetch_row($result)) {
	echo '<tr>';
	foreach($row as $ke => $value){
		echo "<td><center> $value </center></td>" ;
	}

}


echo '</tr>';
}
?>