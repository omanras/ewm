<header>
<?php
include("header.php") ;
?>	


<?php



if($id2 == $id){
// get results from database
#$table = $_GET['Table'];
$table = 'users' ;
#$result = mysqli_query($ConnectDB,"SELECT * FROM $table WHERE groupID = '$id' ") or die(mysqli_error($ConnectDB));
$result = mysqli_query($ConnectDB,"SELECT userId,userName,userEmail,groupName FROM $table WHERE groupID = '$id' ") or die(mysqli_error($ConnectDB));


// display data in table

#if ( isset($_GET['Table'])) {
	echo "<b><h1>$table</h1></b><br>" ;
?>
<div class="box">
  <div class="container-3">
  <?php
  echo "<form action=\"usersearch.php\" name=\"import\" method=\"get\" enctype=\"multipart/form-data\">" ;
  echo '<input id="tea-submit" type="hidden" name="Table" value="',$table,'">' ;
  ?>
  
    <span class="icon"><i class="fa fa-search"></i></span>
	   
      <input type="search" name="search" id="search" placeholder="Search..." /> 
	 </form>
	 
  </div>
</div>
<br>
<br>
<br>
<?php	
#$result =mysqli_query($ConnectDB,"SELECT * FROM $table WHERE") ;
#$result = mysqli_fetch_array($result) ;
echo "<table border='1' cellpadding='10'>";
$result2=mysqli_query($ConnectDB,"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DBname' AND TABLE_NAME = '$table'");
#$result2 = mysqli_fetch_array($result2);
while($res = mysqli_fetch_array($result2)){
foreach($res as $key => $value){
	
	
#echo "<th>$value</th>" ;	
}

#echo "<th>$value</th>" ;
}
echo "<th>userID</th>" ;
echo "<th>username</th>" ;
echo "<th>email</th>" ;
echo "<th>group name</th>" ;
echo '<th> Edit </th>' ;
echo '<th> Delete </th>' ;
echo '<tr>' ;
while($res2 = mysqli_fetch_row($result)){
	
#$res = mysqli_fetch_row($result) ;	
foreach($res2 as $key => $value){
	
	
	echo '<td><center>' . $res2[$key] . '</center></td>' ;
}
$confvalue="return confirm('Are you sure?');";
$confrm = 'onclick='.'"'.$confvalue.'"' ;
$fontdelete ='<center><i class="fa fa-trash"></i></center>' ;
$fontedit='<center><i class="fa fa-pencil"></i></center>' ;

echo "<td><a  href=\"edituser2.php?Table=$table&ID=$res2[0]\">$fontedit </a></td>";

echo "<td><a href=\"userdelete2.php?Table=$table&ID=$res2[0]\" $confrm>$fontdelete</a></td>";
#echo '<td><center>' . $res2[$value] . '</center></td>' ;
echo'</tr>' ;
}




?>







<?php }
else {
	echo "NOT allow " ;
}
#include("footer.php") ;?>

 <?php ob_end_flush(); ?>