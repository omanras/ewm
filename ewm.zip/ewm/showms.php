<?php
include('header.php');
if(isset($_GET['ID'])){
	$msID=$_GET['ID'] ;
	$user=$_GET['user'] ;
	$replayID = $_GET['userID'] ;
	#$query = "SELECT * FROM `message_t` WHERE msID='$msID' AND userResveID='$id2' OR userGroupID='$id'" ;
	$query = "SELECT * FROM `message_t` WHERE msID='$msID'" ;
	$query=mysqli_query($ConnectDB,$query);
	$result=mysqli_fetch_array($query);
	if($result['userResveID'] == '0'){
	$query = "SELECT * FROM `message_t` WHERE msID='$msID' AND userGroupID='$id'" ;
	$query=mysqli_query($ConnectDB,$query);
	$result=mysqli_fetch_array($query);
	
	echo '<b><h1> Title : '.$result['title'] . '</b></h1>';
	echo "<b>From $user To Me </b>";
	#send.php?Table=users&ID=1
	echo "<p><a href=\"send.php?msID=$msID&ID=$replayID\">Replay</a></p>";
	#echo '<textarea style="width:1000px; height:350px;">'.$result['message'].'</textarea>' ;
	echo '<address>'.$result['message'].'</address>' ;
	echo "<p><a href=\"send.php?msID=$msID&ID=$replayID\">Replay</a></p>";
	}
	else{
	$query = "SELECT * FROM `message_t` WHERE msID='$msID' AND userResveID='$id2'" ;
	$query=mysqli_query($ConnectDB,$query);
	$result=mysqli_fetch_array($query);
	
	echo '<b><h1> Title : '.$result['title'] . '</b></h1>';
	echo "<b>From $user To Me </b>";
	#send.php?Table=users&ID=1
	echo "<p><a href=\"send.php?msID=$msID&ID=$replayID\">Replay</a></p>";
	#echo '<textarea style="width:1000px; height:350px;">'.$result['message'].'</textarea>' ;
	echo '<h2>'.$result['message'].'</h2>' ;
	echo "<p><a href=\"send.php?msID=$msID&ID=$replayID\">Replay</a></p>";
	}
}

?>