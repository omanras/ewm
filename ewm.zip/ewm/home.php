﻿

<?php

include('inbox.php') ;

ob_end_flush(); ?>
